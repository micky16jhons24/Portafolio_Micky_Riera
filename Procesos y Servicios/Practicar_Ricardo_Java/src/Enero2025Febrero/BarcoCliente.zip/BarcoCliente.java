package Enero2025Febrero;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class BarcoCliente {

    public static void main(String[] args) {
        String host = "172.16.91.146";
        int puerto = 23456;

        char[][] tableroMIO = new char[5][5];
        char[][] tableroSUYO = new char[5][5];

        inicializarTablero(tableroMIO);
        inicializarTablero(tableroSUYO);

        try (Socket socket = new Socket(host, puerto);
             OutputStream salida = socket.getOutputStream();
             PrintWriter escritor = new PrintWriter(salida, true);
             InputStream entrada = socket.getInputStream();
             BufferedReader lector = new BufferedReader(new InputStreamReader(entrada));
             Scanner sc = new Scanner(System.in)) {

            System.out.println("Conectado al servidor.");
            System.out.println("Tu tablero:");
            imprimirTablero(tableroMIO);

            // Colocar barcos manualmente (2 de tamaño 2 y 2 de tamaño 1)
            System.out.println("Escribe las coordenadas para colocar tus barcos.");
            System.out.println("Formato de coordenadas: fila.col (ejemplo: 1.1)");
            
            // Colocar los barcos de tamaño 2
            for (int i = 0; i < 2; i++) {
                System.out.println("Introduce las coordenadas para el barco de tamaño 2:");
                String[] coordenadasBarco = sc.nextLine().split(" ");
                while (coordenadasBarco.length != 2 || !coordenadasValidas(tableroMIO, coordenadasBarco)) {
                    System.out.println("Error: Debes introducir 2 coordenadas válidas para el barco de tamaño 2:");
                    coordenadasBarco = sc.nextLine().split(" ");
                }
                colocarBarco(tableroMIO, coordenadasBarco);
                imprimirTablero(tableroMIO);
            }

            // Colocar los barcos de tamaño 1
            for (int i = 0; i < 2; i++) {
                System.out.println("Introduce la coordenada para el barco de tamaño 1:");
                String[] coordenadasBarco = { sc.nextLine() };
                while (!coordenadasValidas(tableroMIO, coordenadasBarco)) {
                    System.out.println("Error: Debes introducir una coordenada válida para el barco de tamaño 1:");
                    coordenadasBarco[0] = sc.nextLine();
                }
                colocarBarco(tableroMIO, coordenadasBarco);
                imprimirTablero(tableroMIO);
            }

            String mensaje = "";

            while (!mensaje.equals("salir")) {
                // Pedir al usuario las coordenadas del ataque
                System.out.println("Introduce las coordenadas para atacar (formato: fila,col): ");
                mensaje = sc.nextLine();

                if (mensaje.equals("salir")) {
                    escritor.println("salir");
                    System.out.println("Te desconectaste del servidor.");
                    break;
                }

                // Enviar el mensaje al servidor
                escritor.println(mensaje);

                // Leer respuesta del servidor
                String respuesta = lector.readLine();
                System.out.println("Respuesta del servidor: " + respuesta);

                // Procesar la respuesta y actualizar el tablero del oponente
                RespuestaServidor(respuesta, tableroSUYO);

                // Mostrar tableros
                System.out.println("MI tablero:");
                imprimirTablero(tableroMIO);
                System.out.println("Tablero del oponente:");
                imprimirTablero(tableroSUYO);
            }
        } catch (IOException e) {
            System.err.println("Error en el cliente: " + e.getMessage());
        }
    }

    public static void inicializarTablero(char[][] tablero) {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[i].length; j++) {
                tablero[i][j] = '~';
            }
        }
    }

    public static void imprimirTablero(char[][] tablero) {
        for (char[] fila : tablero) {
            for (char celda : fila) {
                System.out.print(celda + " ");
            }
            System.out.println();
        }
    }

    public static void RespuestaServidor(String respuesta, char[][] tablero) {
        try {
            String[] partes = respuesta.split(",");
            if (partes.length != 3) {
                throw new IllegalArgumentException("Formato de respuesta inválido: " + respuesta);
            }

            int fila = Integer.parseInt(partes[0]);
            int col = Integer.parseInt(partes[1]);
            String resultado = partes[2];

            if (resultado.equalsIgnoreCase("Impacto")) {
                tablero[fila][col] = 'X'; // Barco impactado
            } else if (resultado.equalsIgnoreCase("Agua")) {
                tablero[fila][col] = 'O'; // Ataque fallido
            } else {
                System.err.println("Resultado desconocido: " + resultado);
            }
        } catch (Exception e) {
            System.err.println("Error al procesar la respuesta: " + e.getMessage());
        }
    }

    public static void colocarBarco(char[][] tablero, String[] coordenadas) {
        for (String coordenada : coordenadas) {
            try {
                String[] partes = coordenada.split("\\.");
                int fila = Integer.parseInt(partes[0]) - 1;
                int col = Integer.parseInt(partes[1]) - 1;

                if (fila < 0 || fila >= tablero.length || col < 0 || col >= tablero[fila].length) {
                    System.out.println("Coordenada inválida: " + coordenada);
                    continue;
                }

                if (tablero[fila][col] == '~') {
                    tablero[fila][col] = 'B';
                } else {
                    System.out.println("Ya hay un barco en la posición: " + coordenada);
                }
            } catch (Exception e) {
                System.err.println("Error al procesar la coordenada: " + coordenada);
            }
        }
    }

    public static boolean coordenadasValidas(char[][] tablero, String[] coordenadas) {
        for (String coordenada : coordenadas) {
            try {
                String[] partes = coordenada.split("\\.");
                int fila = Integer.parseInt(partes[0]) - 1;
                int col = Integer.parseInt(partes[1]) - 1;

                if (fila < 0 || fila >= tablero.length || col < 0 || col >= tablero[fila].length) {
                    return false;
                }

                if (tablero[fila][col] != '~') {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }
}
