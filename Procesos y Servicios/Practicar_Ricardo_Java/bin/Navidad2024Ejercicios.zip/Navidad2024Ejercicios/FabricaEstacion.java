package Navidad2024Ejercicios;

public class FabricaEstacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numTrabajadores = 2;
		
		Thread[] Trabajadores = new Thread [numTrabajadores];
		Estacion estacion =new Estacion();
		
		
		for(int i=0; i< Trabajadores.length;i++) {
			Trabajadores[i]=new Thread(new trabajadores(i , estacion));
		}
		
		for(Thread trabajdores : Trabajadores) {
			trabajdores.start();
		}

	}

}

class trabajadores implements Runnable{

	int id;
	Estacion estacion;
	
	public trabajadores(int id , Estacion estacion) {
		this.id=id;
		this.estacion=estacion;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		estacion.E1(id);
		estacion.E2(id);
		estacion.E3(id);
	}
}


class Estacion{
	int cont=1;

	
	public synchronized void E1(int id){
		
		while(cont != 1) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Ejecutando Estacion 1");
        System.out.println("Trabajador " + id + " está trabajando en la Estación 1");

		cont=2;
		notify();
		
	}
	
	public synchronized void E2( int id){
		while(cont != 2) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Ejecutando Estacion 2");
        System.out.println("Trabajador " + id + " está trabajando en la Estación 2");

		
		cont=3;
		notify();
	}

	public synchronized void E3(int id){
		while(cont != 3) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Ejecutando Estacion 3");
		
        System.out.println("Trabajador " + id + " está trabajando en la Estación 3");

		cont=1;
		notify();
	}

	
	
}

