package Navidad2024Ejercicios;

public class HotelesReserva {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numpersonas=6;
		Thread[] clientes=new Thread[numpersonas];
		Habitaciones habitaciones=new Habitaciones();
		
		for(int i=0; i<clientes.length;i++ ) {
			clientes[i]= new Thread(new personas(i, habitaciones)); 
		}
		
		
		for(Thread cliente : clientes) {
			cliente.start();
		}

	}

}


class personas implements Runnable{
	
	int id;
	Habitaciones habitacion;
	public personas(int id, Habitaciones habitacion) {
		this.id=id;
		this.habitacion=habitacion;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("cliente " + id + " intentando reservar una habitacion");
		habitacion.ocupado();
		habitacion.libre(id);
		
		habitacion.DuracionHabitacion(id);
		
	}
	
}


class Habitaciones {
	int reservas=0;
	public synchronized void ocupado() {
		while(reservas == 5) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("todavia hay reservas de habitaciones libres");
		notifyAll();
		
		
	}
	
	public synchronized void libre(int id) {
		while(reservas == 5) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		if(reservas < 5) {
			System.out.println("habitacion resrvada por el cliente " + id );
			reservas++;
			notify();
		}
		if (reservas == 5) {
			System.out.println("habitaciones ocupadas");
		}
	}
	
	public synchronized void DuracionHabitacion(int id) {
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(reservas == 5) {
			System.out.println("habitacion disponible de nuevo, el cliente " + id +" ha dejado la habitacion");
			reservas--;
		}
	}
	
	
}
