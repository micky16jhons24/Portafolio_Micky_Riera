package Ejercicio_After;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Impresora {
    public static void main(String[] args) throws InterruptedException {
        Random random = new Random();
        int numDocumentos = random.nextInt(10) + 1;

        List<Thread> documentos = new ArrayList<>();

        capacidad c = new capacidad();

        for (int i = 0; i < numDocumentos; i++) {
            String nombreDocumento = "Documento- " + (i + 1);
            Thread documento = new Thread(new hiloEnvio(nombreDocumento, c));
            documentos.add(documento);
        }

        for (Thread envio : documentos) {
            envio.start();
        }

        for (Thread envio : documentos) {
            envio.join();
        }

        for (int i = 0; i < numDocumentos; i++) {
            String nombreDocumento = "Documento_ " + (i + 1);
            Thread impresion = new Thread(new hiloImprimiendo(nombreDocumento, c));
            documentos.set(i, impresion);
            impresion.start();
        }

        for (Thread impresion : documentos) {
            impresion.join();
        }
        
        while (true) {
            Thread.sleep(10000); 
        }

       
    }
}

class hiloEnvio implements Runnable {
    private String nombre;
    private capacidad c;

    public hiloEnvio(String nombre, capacidad c) {
        this.nombre = nombre;
        this.c = c;
    }

    @Override
    public void run() {
        try {
            System.out.println("Se están enviando documentos: " + nombre + " .......");
            Thread.sleep((long) (Math.random() * 4000) + 1000);
            c.reponer();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class hiloImprimiendo implements Runnable {
    private String nombre;
    private capacidad c;

    public hiloImprimiendo(String nombre, capacidad c) {
        this.nombre = nombre;
        this.c = c;
    }

    @Override
    public void run() {
        try {
        	while (true) {
                c.esperar();
                System.out.println("Se está imprimiendo el documento: " + nombre + " este proceso puede durar entre 0,5 y 5 segundos");
                Thread.sleep((long) (Math.random() * 2500) + 5000);
                System.err.println("Ya se ha impreso el documento: " + nombre);
                c.documentoImpresion(); 
            }   
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}

class capacidad {
    private int cola = 0;

    public synchronized void esperar() throws InterruptedException {
        while  (cola <=0)  {
            wait();
        }
    }

    public synchronized void reponer() throws InterruptedException {
        cola++;
        System.out.println("Documento añadido a la cola. Número de documentos en la cola: " + cola);
        notifyAll();
    }

    public synchronized void documentoImpresion() {
        cola--;
        if (cola <0) {
            cola=0; 
        }
        notifyAll();
    }
}
